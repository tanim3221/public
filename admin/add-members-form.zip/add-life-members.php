<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
	{	
header('location:login.php');
}
else{ 

if(isset($_POST['submit']))
  {
$memid=$_POST['mem_id'];
$name=$_POST['name'];
$mailing=$_POST['mailing_add'];
$permanent=$_POST['permanent_add'];
$mobile=$_POST['mobile'];
$email=$_POST['email'];
$profesion=$_POST['profesion'];
$designation=$_POST['designation'];
$organization=$_POST['organization'];
$bachelor=$_POST['bachelor_year'];
$master=$_POST['master_year'];
$categorym=$_POST['m_category'];
$ruaaapost=$_POST['ruaaa_post'];
$status=0;


  $image_file = $_FILES["image"]["name"];
  $type  = $_FILES["image"]["type"]; //file name "image" 
  $size  = $_FILES["image"]["size"];
  $temp  = $_FILES["image"]["tmp_name"];
  
  $path="../img/lm/".$image_file; //set upload folder path
  

   if(!file_exists($path)) //check file not exist in your upload folder path
   {

     move_uploaded_file($temp, "../img/lm/" .$image_file);
   }

$sql="INSERT INTO  lifemembers (MemId,Name,Mailing,Permanent,Mobile,Email,Profession,Designation,Organization, Bachelor, Master, CategoryM, RuaaaPost, Image, status) VALUES(:memid,:name,:mailing,:permanent,:mobile,:email,:profesion,:designation,:organization,:bachelor,:master,:categorym,:ruaaapost, :image, :status)";
$query = $dbh->prepare($sql);
$query->bindParam(':memid',$memid,PDO::PARAM_STR);
$query->bindParam(':name',$name,PDO::PARAM_STR);
$query->bindParam(':mailing',$mailing,PDO::PARAM_STR);
$query->bindParam(':permanent',$permanent,PDO::PARAM_STR);
$query->bindParam(':mobile',$mobile,PDO::PARAM_STR);
$query->bindParam(':email',$email,PDO::PARAM_STR);
$query->bindParam(':profesion',$profesion,PDO::PARAM_STR);
$query->bindParam(':designation',$designation,PDO::PARAM_STR);
$query->bindParam(':organization',$organization,PDO::PARAM_STR);
$query->bindParam(':bachelor',$bachelor,PDO::PARAM_STR);
$query->bindParam(':master',$master,PDO::PARAM_STR);
$query->bindParam(':categorym',$categorym,PDO::PARAM_STR);
$query->bindParam(':ruaaapost',$ruaaapost,PDO::PARAM_STR);
$query->bindParam(':image',$image_file,PDO::PARAM_STR);
$query->bindParam(':status',$status,PDO::PARAM_STR);
$query->execute();

$lastInsertId = $dbh->lastInsertId();
if($lastInsertId)
{
$msg="Your info submitted successfully";
}
else 
{
$error="Something went wrong. Please try again";
}

}


	?>
<!doctype html>
<html lang="en" class="no-js">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="theme-color" content="#3e454c">
	
	<title>RUAAA || Member Database</title>

	<!-- Font awesome -->
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<!-- Sandstone Bootstrap CSS -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<!-- Bootstrap Datatables -->
	<link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
	<!-- Bootstrap social button library -->
	<link rel="stylesheet" href="css/bootstrap-social.css">
	<!-- Bootstrap select -->
	<link rel="stylesheet" href="css/bootstrap-select.css">
	<!-- Bootstrap file input -->
	<link rel="stylesheet" href="css/fileinput.min.css">
	<!-- Awesome Bootstrap checkbox -->
	<link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css">
	<!-- Admin Stye -->
    <link rel="stylesheet" href="css/style.edit.form.css">
	<link rel="stylesheet" href="css/style.css">
<style>
		.errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #dd3d36;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #5cb85c;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
		</style>
<script language="javascript">
function isNumberKey(evt)
      {
         
        var charCode = (evt.which) ? evt.which : event.keyCode
                
        if (charCode > 31 && (charCode < 48 || charCode > 57) && charCode!=46)
           return false;

         return true;
      }
      </script>
</head>

<body>
	<?php include('includes/header.php');?>
	<div class="ts-main-content">
	<?php include('includes/leftbar.php');?>
		<div class="content-wrapper">
			<div class="container-fluid">

				<div class="row">
					<div class="col-md-12">
					
						<h2 class="page-title">Add Life Members</h2>

						<div class="row">
							<div class="col-md-12">

<?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php } 
				else if($msg){?><div class="succWrap"><strong>SUCCESS</strong>:<?php echo htmlentities($msg); ?> </div><?php }?>

									<div class="panel-body">
									
<form class="form-group" method="post" name="myform" id="myform" enctype="multipart/form-data">
                <div class="row">
                    <div class="col-md-4">
                        <div class="profile-img">
                        
                        <img src="../ruaaa.png" id="profile-img-tag" width="100px" />
                        <p> <h6>Upload Photo</h6>
                            <input class="form-control" type="file" id="file" name="image" onchange="show(this)"></p>
                            
                        
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="profile-head">
                        
                                        <div class="row">
                                            <div class="col-md-4">
                                                <label>Name</label>
                                            </div>
                                            <div class="col-md-8">
                                                <p><input class="form-control" type="text" name="name" required ></p>
                                            </div>
                                        </div>
                                        
                                         <div class="row">
                                            <div class="col-md-4">
                                                <label>Member ID</label>
                                            </div>
                                            <div class="col-md-8">
                                                <p> <input class="form-control" type="text" name="mem_id" required ></p>
                                            </div>
                                        </div>
                                        
                                        <div class="row">
                                            <div class="col-md-4">
                                                <label>Member Category</label>
                                            </div>
                                            <div class="col-md-8">
                                                <p> <select class="form-control" name="m_category" required >
  
                                          <option value="LM" name="LM" > Life Member </option>
                                          <option value="DDM" name="DDM"  > Distinguished Donor Member </option>
                                          <option value="GDM" name="GDM" > Grand Donor Member </option>
                                          <option value="GM" name="GM" > Golden Member </option>
                                        </select></p>
                                            </div>
                                        </div>
                                        
                                        <div class="row">
                                            <div class="col-md-4">
                                                <label>RUAAA Committee Designation</label>
                                            </div>
                                            <div class="col-md-8">
                                            <p> <select class="form-control" name="ruaaa_post">
                                            <option value="" >    Select RUAAA Designation  </option>
                                    <option value="President" >    President  </option>
                                  <option value="Vice President (1) ">  Vice President (1) </option>
                                  <option value="Vice President (2)">  Vice President (2) </option>
                                  <option value=" Vice President (3)">  Vice President (3) </option>
                                <option value="General Seretary">	General Seretary </option>
                                  <option value="Tresurer">  Tresurer </option>
                                  <option value="Joint Seretary (1)">  Joint Seretary (1) </option>
                                <option value="Joint Seretary (2)">	Joint Seretary (2) </option>
                                <option value="Organizing Secretary (1)">	Organizing Secretory (1) </option>
                                <option value="Organizing Secretary (2)">	Organizing Secretary (2) </option>
                                  <option value="Office and Press Secretary">  Office and Press Secretary </option>
                                  <option value="Member">  Member </option>
 
                                            
                                            </select></p>
                                            </div>
                                        </div>
                                    
    
                        </div>
                    </div>
       
                </div>
                <div class="row">
            
                
                    <div class="col-md-12">
                        <div class="tab-content profile-tab" id="myTabContent">
                            <div class="tab-pane fade show active in" id="home" role="tabpanel" aria-labelledby="home-tab">
                                        <div class="row">
                                            <div class="col-md-3">
                                                <label>Mailing Address</label>
                                            </div>
                                            <div class="col-md-9">
                                                <p><textarea rows="6" class="form-control" type="text" name="mailing_add" required ></textarea></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-3">
                                                <label>Permanent Address</label>
                                            </div>
                                            <div class="col-md-9">
                                                <p> <textarea rows="6" class="form-control" type="text" name="permanent_add" ></textarea></p>
                                            </div>
                                        </div>
                                        
                                        
                                        <div class="row">
                                            <div class="col-md-3">
                                                <label>Profession</label>
                                            </div>
                                            <div class="col-md-9">
                                                <p><input class="form-control" type="text" name="profesion" ></p>
                                            </div>
                                        </div>
                                        
                                        <div class="row">
                                            <div class="col-md-3">
                                                <label>Designation</label>
                                            </div>
                                            <div class="col-md-9">
                                                <p><input class="form-control" type="text" name="designation" ></p>
                                            </div>
                                        </div>
                                        
                                        <div class="row">
                                            <div class="col-md-3">
                                                <label>Organization</label>
                                            </div>
                                            <div class="col-md-9">
                                                <p><input class="form-control" type="text" name="organization" ></p>
                                            </div>
                                        </div>
                                        
                                        
                                        
                                        
                                        
                                        <div class="row">
                                            <div class="col-md-3">
                                                <label>Mobile</label>
                                            </div>
                                            <div class="col-md-9">
                                                <p><input class="form-control" type="text" name="mobile" required ></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-3">
                                                <label>Email</label>
                                            </div>
                                            <div class="col-md-9">
                                               <p> <input class="form-control" type="text" name="email" ></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-3">
                                                <label>Bachelor Year</label>
                                            </div>
                                            <div class="col-md-9">
                                                <p><input class="form-control" type="text" name="bachelor_year" ></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-3">
                                                <label>Master Year</label>
                                            </div>
                                            <div class="col-md-9">
                                                <p><input class="form-control" type="text" name="master_year" ></p>
                                            </div>
                                        </div>
                                    
                            </div>
                            </div>
                        </div>
                        
                    </div>
              
            
  <input class="btn btn-success" type="submit" id="btnSubmit" name="submit" value="Submit" />
</form>
									
									
</div>
								</div>
							</div>
						</div>
						
					

					</div>
				</div>
				
			

			</div>
		</div>
	</div>

<!-- Loading Scripts -->
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap-select.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.dataTables.min.js"></script>
	<script src="js/dataTables.bootstrap.min.js"></script>
	<script src="js/Chart.min.js"></script>
	<script src="js/fileinput.js"></script>
	<script src="js/chartData.js"></script>
		<script src="js/imgValidationSize.js"></script>
	<script src="js/main.js"></script>
</body>        

</body>
</html>
<?php } ?>
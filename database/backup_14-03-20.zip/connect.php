<?php
	$conn = mysqli_connect("localhost", "ruaatvfg_wp840", "9SX.8-3opJ", "ruaatvfg_members_db");
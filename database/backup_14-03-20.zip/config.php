<?php 
// DB credentials.
define('DB_HOST','localhost');
define('DB_USER','ruaatvfg_wp840');
define('DB_PASS','9SX.8-3opJ');
define('DB_NAME','ruaatvfg_members_db');
// Establish database connection.
try
{
$dbh = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME,DB_USER, DB_PASS,array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
}
catch (PDOException $e)
{
exit("Error: " . $e->getMessage());
}
?>
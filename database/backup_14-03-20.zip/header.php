<div class="navbar-top">
	<div class="row">
		<div class="col-md-1" id="img-title1"><img style="float:left;" src="ruaaa.png" /></div>
		<div class="col-md-2" id="img-title3"><img src="ruaaa-logo.png" /></div>
		<div class="col-md-10" id="text-title" style="text-align:center;" >

			<span class="GrayBlue14b">Rajshahi University Accounting Alumni Association (RUAAA)</span><br />
			<span class="GrayBlue20bold">Dept. of AIS, University of Rajshahi</span><br />
			<span class="GrayBlue20bold">Rajshahi– 6205, Bangladesh</span>
		</div>
		<div class="col-md-1" id="img-title2" ><img style="float:right;" src="ru-logo.png"  /></div>
  </div>
 </div>

<nav class="navbar navbar-expand-md bg-dark navbar-dark sticky-top">
  <a class="navbar-brand" href="index.php">RUAAA</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a href="grand-donor-members.php" class="nav-link"><i class="fa fa-user"></i> Grand Donor Member</a>
      </li>
      <li class="nav-item">
        <a href="distinguished-donor-members.php" class="nav-link"><i class="fa fa-user"></i> Distinguished Donor Member</a>
      </li>
      <li class="nav-item">
        <a href="golden-members.php" class="nav-link"><i class="fa fa-user"></i> Golden Member</a>
      </li>  

	<li class="nav-item">
        <a href="life-members.php" class="nav-link"><i class="fa fa-user"></i> Life Member</a>
      </li> 
	<li class="nav-item">
        <a href="general-members.php" class="nav-link"><i class="fa fa-user"></i> General Members</a>
      </li> 
	  <div class="dropdown-divider"></div>
       <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown"><i class="fa fa-plus-circle"></i>  Registration </a>
      <div class="dropdown-menu">
        <a class="dropdown-item" href="registration-info.php"><i class="fa fa-info-circle"></i>  Registration Information</a>
        <a class="dropdown-item" href="new-members-registration.php"><i class="fa fa-plus-circle"></i>  New Members registration </a>
        <a class="dropdown-item" href="payment-fees.php"><i class="fa fa-check-circle"></i>  Registration for program</a>
      </div>
    </li>
 
<li class="nav-item">
        <a href="javascript:void(0)" onclick="location.href='complain-form.php'"  class="nav-link"><i class="fa fa-exclamation-circle"></i>   Complain</a>
      </li> 		  
    </ul>
  </div>  
</nav>

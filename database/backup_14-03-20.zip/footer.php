<div class="footer-bottom">
	<div class="row">
	<div class="col-md-3" id="browser" style="text-align:left">
        For Better Browsing Experience<br>
      <img style="width:30px; height:30px;" src="Chrome.png" ><img style="width:30px; height:30px;" src="Firefox.png" ><img style="width:30px; height:30px;" src="Edge.png" >
    </div>
	
        <div class="col-md-6" id="middle-text" style="text-align:center;">
        Please contact for Registration and Information: Tel.: +880 721 711133, +880 721 711651; Email: alumniaisru@gmail.com • Website: http://www.ruaaa.org
        </div>
        <div class="col-md-3" id="name-pro" style="text-align:right;">
            Design & Developed by
            <br><span class="pro-link"><a href="https://www.linkedin.com/in/saklayen" >Saklayen Ahmed</a></span> - <span class="pro-session">BBA 19th Batch</span>
            <br><span class="pro-uni"></span>
        </div>
    </div>
</div>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>Rajshahi University Accounting Alumni Association (RUAAA)</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="cache-control" content="no-cache" />
<meta name="publisher" content="Dept. of AIS, University of Rajshahi" />
<meta name="copyright" content="Rajshahi University Accounting Alumni Association (RUAAA)" />
<meta name="author" content="Design/Developed by: Saklayen Ahmed :: BBA 2018" />
<meta name="robots" content="index, follow" />
<meta name="description" content="Rajshahi University Accounting Alumni Association (RUAAA)" />

	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
	<link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css">
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/bootstrap-select.css">
	<link rel="stylesheet" href="css/main.css">
	<link rel="stylesheet" href="css/res.css">
	<link rel="stylesheet" media="print" href="css/print.css">
        
     <script src="js/jquery.min.js"></script>
	 <script src="js/popper.min.js"></script>
	<script src="js/bootstrap.bundle.min.js"></script>
	<script src="js/jquery.dataTables.min.js"></script>
	<script src="js/dataTables.bootstrap.min.js"></script>
	<script src="js/Chart.min.js"></script>
	<script src="js/bootstrap-select.js"></script>
	<script src="js/fileinput.js"></script>
	<script src="js/chartData.js"></script>
	<script src="js/imgValidationSize.js"></script>
	<script src="js/imgView.js"></script>
        <script src="js/imgValidationType.js"></script>
	<script src="js/imgValidation.js"></script>
	<script src="js/main.js"></script>
	<script src="js/cross.checking.js"></script> 
</head>

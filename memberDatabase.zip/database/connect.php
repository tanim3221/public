<?php
	$conn = mysqli_connect("localhost", "root", "", "ruaaa_v2");

    <button onclick="topFunction()" id="myBtn" title="Go to top"><i class="icon-chevron-up"></i></button>
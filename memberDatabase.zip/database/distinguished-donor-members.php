<!DOCTYPE html>
<html lang="en">
<head>
	<?php include('config.php'); ?>
	<?php include('head.php'); ?>
</head>

	<body>

		<div class="container-fluid">

			
				<?php include('header.php'); ?>
			

			<div class="container-body">
				<?php include("ddm-view.php");?>
			</div>

			<div class="container-footer">
				<?php include('footer.php'); ?>
			</div>

		</div>

	</body>
</html>
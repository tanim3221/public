<?php include 'head.php';?>

<div class="jumbotron text-center">
                     <img src="../ruaaa.png" class="img-circle" alt="RUAAA"><h3>Rajshahi University Accounting Alumni Association</h3>
<p>Member Database Management System</p>
            


  </div>
  
  <style>
  img.img-circle {
    width: 100px;
}
  </style>
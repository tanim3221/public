<div class="brand clearfix">
      <a style="color: #fff;" class="navbar-brand" href="index.php">RUAAA | Admin</a> 	 
		<span class="menu-btn"><i class="fa fa-bars"></i></span>
		<ul class="ts-profile-nav">
			
			<li class="ts-account">
				<a href="#"><i class="fa fa-user"></i> <i class="fa fa-caret-down hidden-side"></i></a>
				<ul>
				<li><a target="_blank" href="http://ruaaa.org/member">View Site</a></li>
					<li><a href="change-password.php">Change Password</a></li>
					<li><a href="logout.php">Logout</a></li>
				</ul>
			</li>
		</ul>
	</div>

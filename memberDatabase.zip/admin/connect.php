<?php

//database_connection.php
$conn = mysqli_connect("localhost","root","","ruaaa_v2");

?>
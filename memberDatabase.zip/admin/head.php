<head>
   <title>RUAAA Member Database</title>
  
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta content='Members Database | RUAAA' property='og:title' />
    <meta property="og:type" content="RUAAA Database | RU" />
    <meta content='An initiative by RUAAA' property='og:description' />
    <meta property="og:image" content="img.jpg">
    <meta property="og:url" content="http://www.ruaaa.org" />

    <link rel="icon" href="favicon.ico" type="image/x-generic" />

    <link rel="icon" href="favicon.ico" type="image/x-icon" />
    <link rel="stylesheet" href="../style/style.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="../style/res.css?v=<?php echo time(); ?>">
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css" rel="stylesheet">

</head>
